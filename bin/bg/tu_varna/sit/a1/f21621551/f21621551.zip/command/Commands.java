package bg.tu_varna.sit.a1.f21621551.command;

public interface Commands {
    void execute();
}